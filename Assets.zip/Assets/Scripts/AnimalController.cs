using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;

public class AnimalController : MonoBehaviour
{
    [SerializeField] private AnimalSO _animalDefinition;
    [SerializeField] private GlobalContext _context;
    [SerializeField] private float _grabSpeed = 2;
    [SerializeField] private Vector3 _grabRotation;
    [SerializeField] private Transform _model;
    [SerializeField] private AudioSource _grabSound;
    private Rigidbody _rigidbody;

    private bool _isDelivered;

    private Transform _grabTransform;
    private bool _isGrabbed;

    private float _grabProgress;

    private Terrain _terrain;

    private Vector3 _defaultRotation;

    private bool _wasGrabbedThisFrame;
    

    private void Awake()
    {
        _rigidbody = GetComponent<Rigidbody>();
        _defaultRotation = _model.localRotation.eulerAngles;
    }

    private void Start()
    {
        _terrain = FindObjectOfType<Terrain>();
        AdjustPositionToTerrain(transform);
    }

    // Update is called once per frame
    void Update()
    {
        if (_isGrabbed)
        {
            _grabProgress += Mathf.Clamp01(Time.deltaTime * _grabSpeed);
            
            if (Vector3.Distance(transform.position, _grabTransform.position) < 0.1f)
            {
                transform.parent = _grabTransform;
                transform.position = _grabTransform.position;

                if (_wasGrabbedThisFrame)
                {
                    if (_grabSound)
                    {
                        _grabSound.PlayOneShot(_grabSound.clip);
                    }

                    _wasGrabbedThisFrame = false;
                }
                
            }
            else
            {
                transform.position = Vector3.Lerp(transform.position, _grabTransform.position, _grabProgress);
                _model.localRotation = Quaternion.Euler(Vector3.Lerp(transform.rotation.eulerAngles, _grabRotation, _grabProgress));
            }
        }
        else
        {
            _grabProgress = 0;
            _model.localRotation = Quaternion.Euler(Vector3.Lerp(transform.rotation.eulerAngles, _defaultRotation, 1));
        }
    }

    //TODO consider using physics and physics player contorller so animal can hang naturally when grabbed
    private void SetPhysicsState(bool state)
    {
        _rigidbody.useGravity = state;
        _rigidbody.isKinematic = !state;
    }

    private void SetCollidersState(bool state)
    {
        foreach (var c in GetComponentsInChildren<Collider>())
        {
            c.enabled = state;
        }
    }

    public void OnGrab(Transform parent)
    {
        _isGrabbed = true;
        _grabTransform = parent;
        _wasGrabbedThisFrame = true;
//        transform.parent = parent;
//        transform.localPosition = Vector3.zero;
//        transform.position = Vector3.Lerp(transform.position, parent.position, Time.deltaTime*10);
        SetPhysicsState(false);
        SetCollidersState(false);
        SetDeliveredState(false);
    }

    public void OnDrop()
    {
        _isGrabbed = false;
        transform.parent = null;
        SetPhysicsState(true);
        SetCollidersState(true);
    }

    public void SetDeliveredState(bool isDelivered)
    {
        if (_isDelivered != isDelivered)
        {
            _isDelivered = isDelivered;
            _context.State.UpdateAnimalDeliveryState(this, isDelivered);
        }
       
    }
    
    private void AdjustPositionToTerrain(Transform transform)
    {
        var y = _terrain.SampleHeight(transform.position);
        var adjustedPosition = transform.position;
        adjustedPosition.y = y;
        transform.position = adjustedPosition;
    }


    public AnimalSO AnimalDefinition => _animalDefinition;
}
