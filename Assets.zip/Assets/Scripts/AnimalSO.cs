using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "LudumDare/Animal")]
public class AnimalSO : ScriptableObject
{

    public string Name;

}
