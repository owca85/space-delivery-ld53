﻿using UnityEngine;

public static class ExtensionMethods {

    public static Vector3 Flatten(this Vector3 vector) {
        return new Vector3(vector.x, 0, vector.z);
    }


    public static string FormatWithSuffix(this float value) {
        if (value >= 1000000) {
            return string.Format("{0:0.0}M", value / 1000000);
        }

        if (value >= 1000) {
            return string.Format("{0:0.0}k", value / 1000);
        }

        return value.ToString();
    }
}