﻿using System;
using UnityEngine;

public class Health : MonoBehaviour {

    [SerializeField] private FloatReference _health;
    [SerializeField] private FloatReference _healthNormalized;
    [SerializeField] private float _multiplier = 1;
    private bool _isDead;
    private bool _initialized;

    private float _initialHealth;
    
    public event Action OnHit;
    public event Action OnKilled;

    public void Initialize(float amount) {
        if (!_initialized) {
            _initialHealth = amount * _multiplier;
            _health.Set(_initialHealth);
            UpdateNormalizedHealth();
            _initialized = this;
        }
        else {
//            Debug.LogWarning($"Health already initialized", gameObject);
        }
    }

    public void DealDamage(float amount) {
        _health.Set(_health.Value - amount);
        UpdateNormalizedHealth();
        OnHit?.Invoke();
        if (_health.Value <= 0) {
            OnKilled?.Invoke();
            _isDead = true;
        }
    }

    public bool IsDead => _isDead;


    private void UpdateNormalizedHealth() {
        _healthNormalized.Set(_health / _initialHealth);
    }
}