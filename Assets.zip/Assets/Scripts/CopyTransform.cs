using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CopyTransform : MonoBehaviour
{
    [SerializeField] private Transform _target;
    [SerializeField] private float _positionCopySpeed;
    [SerializeField] private float _rotationCopySpeed;
    

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.Lerp(transform.position, _target.position, Time.deltaTime * _positionCopySpeed);
        transform.rotation = Quaternion.Lerp(transform.rotation, _target.rotation, Time.deltaTime * _rotationCopySpeed);
    }
}
