using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class DropArea : MonoBehaviour
{
    [SerializeField] private bool _acceptAnyAnimal;
    [SerializeField] private AnimalSO[] _validAnimals;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Animal"))
        {
            var animal = other.gameObject.GetComponentInParent<AnimalController>();
            if (_acceptAnyAnimal || _validAnimals.Contains(animal.AnimalDefinition))
            {
                animal.SetDeliveredState(true);
//                Debug.Log($"Animal Delivered: {animal}", animal);
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("Animal"))
        {
            var animal = other.gameObject.GetComponentInParent<AnimalController>();
            if (_acceptAnyAnimal || _validAnimals.Contains(animal.AnimalDefinition))
            {
                animal.SetDeliveredState(false);
//                Debug.Log($"Animal Un-Delivered: {animal}", animal);
            }
        }
    }
}
