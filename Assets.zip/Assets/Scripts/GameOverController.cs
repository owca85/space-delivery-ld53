using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameOverController : MonoBehaviour
{
    [SerializeField] private GlobalContext _context;
    [SerializeField] private GameObject _panel;
    [SerializeField] private TextMeshProUGUI _reason;
    [SerializeField] private Button _restartButton;


    private void Start()
    {
        _panel.SetActive(false);
    }

    private void OnEnable()
    {
        _context.State.OnGameOver += OnGameOver;
    }

    private void OnDisable()
    {
        _context.State.OnGameOver -= OnGameOver;
    }

    private void OnGameOver(string reason)
    {
        Cursor.lockState = CursorLockMode.None;
        _reason.text = reason;
        _panel.SetActive(true);
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(0);
    }

    public void Exit()
    {
        Application.Quit();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
