using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "LD53/GlobalSettings",fileName = "GlobalSettings")]
public class GameSettings : ScriptableObject
{

    public PlayerSettings Player;
    public ScoringSettings Scoring;
    
    
    [Serializable]
    public class PlayerSettings {
        public float InitialHealth;
        public float InitialFuel;
        public float MinFuelToNitro;
        public float NitroFuelConsumtionMultiplier;
        public float FuelConsumptionPerSecond;
        
    }
    
    [Serializable]
    public class ScoringSettings {
        public float TimeLimit;
    }
}
