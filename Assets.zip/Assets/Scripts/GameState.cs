﻿using System;
using UnityEngine;
using UnityEngine.PlayerLoop;

[CreateAssetMenu(menuName = "LD53/GameState")]
public class GameState : ScriptableObject {
    public bool IsGamePaused;
    public bool IsGameOver;
    public bool IsPlayerDead;
    public FloatReference SoundVolume;
    
    //game variables
    public IntReference AnimalsDelivered;

    public event Action<string> OnGameOver;
    public event Action OnGameWin;
    public event Action<AnimalController, bool> OnAnimalDeliveryStateUpdate;
    public event Action<int> OnPlayerHit;
    public event Action OnTimeout;

    public void Reset() {
        IsGamePaused = false;
        IsGameOver = false;
        IsPlayerDead = false;
        AnimalsDelivered.Set(0);
        UnpauseGame();
        RestoreSoundVolume();
    }

    private void RestoreSoundVolume() {
        var volume = PlayerPrefs.HasKey("soundVolume") ? PlayerPrefs.GetFloat("soundVolume") : 1; 
        SoundVolume.Set(volume);
    }
    

    private void MuteSounds() {
        SoundVolume.Set(0.001f);
    }

    public void UpdateAnimalDeliveryState(AnimalController animalController, bool isDelivered) {
        OnAnimalDeliveryStateUpdate?.Invoke(animalController, isDelivered);
        AnimalsDelivered.Set(AnimalsDelivered + (isDelivered ? 1 : -1));
//        Debug.Log($"Is animal delivered: {isDelivered}. Animal: {animalController.AnimalDefinition}", animalController.gameObject);
    }

    public void PlayerHit(int damage)
    {
         OnPlayerHit?.Invoke(damage);
//        Debug.Log($"Player hit by {damage} damage");
    }
    
    public void PlayerDead()
    {
//        OnPlayerHit?.Invoke(damage);
//        Debug.Log($"Player is dead");
        IsGameOver = true;
        OnGameOver?.Invoke("You were destroyed!");
    }
    
    public void OutOfFuel()
    {
        IsGameOver = true;
        OnGameOver?.Invoke("Out of fuel!");
    }
    
    public void TimeOut()
    {
        OnTimeout?.Invoke();
//        Debug.Log($"Out of time");
        OnGameOver?.Invoke("Time's up!");
    }
    
    public bool IsInputDisabled => IsGamePaused || IsGameOver || IsPlayerDead;

    public void PauseGame() {
        IsGamePaused = true;
        Time.timeScale = 0;
    }

    public void UnpauseGame() {
        IsGamePaused = false;
        Time.timeScale = 1;
    }

    public void ToggleGamePause() {
        if (IsGamePaused) {
            UnpauseGame();
        }
        else {
            PauseGame();
        }
    }

    public void GameWon() {
        OnGameWin?.Invoke();
        IsGameOver = true;
    }
}