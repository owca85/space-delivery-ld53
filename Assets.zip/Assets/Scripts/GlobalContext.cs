﻿using UnityEngine;

[CreateAssetMenu(menuName = "LD53/GlobalContext")]
public class GlobalContext : ScriptableObject {
    public GameSettings Settings;
    public GameState State;
}