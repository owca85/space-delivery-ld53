﻿using UnityEngine;

public class Init : MonoBehaviour {
    [SerializeField] private GlobalContext _context;

    private void Awake() {
        _context.State.Reset();
    }
}