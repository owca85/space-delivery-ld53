using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Assertions.Comparers;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private GlobalContext _context;
    [SerializeField] private float _movementSpeed;
    [SerializeField] private float _maxSpeed;
    [SerializeField] private float _nitroSpeed;
    [SerializeField] private float _desiredHeight;
    [SerializeField] private float _antiGravityFactor;
    [SerializeField] private float _movementIntertia;
    [SerializeField] private float _maxAngle;
    [SerializeField] private float _rotationSpeed;
    [SerializeField] private AudioSource _vaccumSound;
    [SerializeField] private AudioSource _hitSound;
    [SerializeField] private float _vaccumSoundVolume = 0.5f;
    
    [SerializeField] private IntReference _playerHealth;
    [SerializeField] private FloatReference _fuelLevel;

    [SerializeField] private Material _hitMaterial;
    
    [SerializeField] private float _grabDistance;
    
    [SerializeField] private Transform _model;
    [SerializeField] private Transform[] _grabPoints;

    [SerializeField] private LayerMask _animalLayerMask;
    
    [SerializeField] private int _maxHeldAnimals = 3;

    [SerializeField] private ParticleSystem _vaccumEffect;
    
    [SerializeField]
    private float _mouseSensitivity;

    private float _xAxis;
    private float _zAxis;
    private bool _nitroPressed;

   
    
    private Rigidbody _rigidbody;

//    private int _heldAnimalsCount;
    private List<AnimalController> _heldAnimals = new List<AnimalController>();

    private bool _isUsingNitro;

    private Material _defaultMaterial;
    private MeshRenderer _meshRenderer;

    private Terrain _terrain;
    private float _yOffset;
   

    private void Awake()
    {
        _meshRenderer = GetComponentInChildren<MeshRenderer>();
        _defaultMaterial = _meshRenderer.material;
        _rigidbody = GetComponentInChildren<Rigidbody>();
    }

    private void Start()
    {
        _playerHealth.Set((int) _context.Settings.Player.InitialHealth);
        _fuelLevel.Set(_context.Settings.Player.InitialFuel);
        Cursor.lockState = CursorLockMode.Locked;
        _terrain = FindObjectOfType<Terrain>();
        _yOffset = transform.position.y;
    }

    private void OnEnable()
    {
        _context.State.OnPlayerHit += OnPlayerHit;
    }

    private void OnDisable()
    {
        _context.State.OnPlayerHit -= OnPlayerHit;
    }

    private void OnPlayerHit(int damage)
    {
        CameraShake.Instance.Shake(1, 0.2f);

        if (_hitSound)
        {
            _hitSound.PlayOneShot(_hitSound.clip);
        }
        
        _playerHealth.Set(_playerHealth - damage);
        if (_playerHealth <= 0)
        {
            _context.State.PlayerDead();
        }

        _meshRenderer.material = _hitMaterial;

        Invoke("ResetMaterial", 0.1f);
    }

    private void ResetMaterial()
    {
        _meshRenderer.material = _defaultMaterial;
    }
    
    public Vector3 GetPredictedPosition(float deltaTime)
    {
        return transform.position + _rigidbody.velocity * deltaTime;
        
        return transform.position + new Vector3(_xAxis, 0, _zAxis).normalized * _movementSpeed * deltaTime;
    }

    private void FixedUpdate()
    {
//        HandleMovement();
        HandleTerrainOffset();
    }

    void Update()
    {
        if (_context.State.IsInputDisabled)
        {
            return;
        }
        
        //TODO movementInertia should make player start movement slowly and stop slowly - now it's just adding a delay
        _zAxis = Mathf.Lerp(_zAxis, RoundInput(Input.GetAxis("Vertical")), Time.deltaTime * _movementIntertia);
        _xAxis = Mathf.Lerp(_xAxis, RoundInput(Input.GetAxis("Horizontal")), Time.deltaTime * _movementIntertia);
        _nitroPressed = Input.GetButton("Nitro") || Input.GetMouseButton(2);
        
//        Debug.Log($"xAxis: {RoundInput(Input.GetAxis("Horizontal"))}, zAxis: {RoundInput(Input.GetAxis("Vertical"))}");

//        HandleTerrainOffset();
        HandleMovement();

//        RotateModelTowardsMovementDirection(_zAxis, _xAxis);

        HandleGrabAndDrop();

        HandleRotation();

        HandleFuel();
    }

    private void HandleMovement()
    {
//        _rigidbody.AddForce(-Physics.gravity, ForceMode.Acceleration);
//        bool isGrounded = Physics.Raycast(transform.position, Vector3.down, out RaycastHit hit);
//        float distanceToGround;
//        if (isGrounded) {
//            distanceToGround = hit.distance;
//        } else {
//            distanceToGround = float.PositiveInfinity;
//        }
//        float error = _desiredHeight - distanceToGround;
//        float antiGravity = _antiGravityFactor * error;
//        _rigidbody.AddForce(Vector3.up * antiGravity, ForceMode.Force);
        
        
        var effectiveSpeed = _movementSpeed;
        var force = new Vector3(_xAxis, 0, _zAxis).normalized * effectiveSpeed * Time.fixedDeltaTime;
        var v = transform.forward * force.z + transform.right * force.x;
        
        if (CanUseNitro() && _nitroPressed)
        {
            _rigidbody.AddForce(v, ForceMode.VelocityChange);
            _rigidbody.AddForce(v.normalized * _nitroSpeed, ForceMode.VelocityChange);
        
            if (_rigidbody.velocity.sqrMagnitude > _nitroSpeed * _nitroSpeed)
            {
//                _rigidbody.AddForce(-transform.forward * _nitroSpeed, ForceMode.VelocityChange);
                _rigidbody.velocity = Vector3.Lerp(_rigidbody.velocity, _rigidbody.velocity.normalized * _nitroSpeed, Time.deltaTime*1);
            }
        }
        else
        {
            _rigidbody.AddForce(v, ForceMode.VelocityChange);
            if (_rigidbody.velocity.sqrMagnitude > effectiveSpeed * effectiveSpeed)
            {
                _rigidbody.velocity = _rigidbody.velocity.normalized * effectiveSpeed;
            }
        }
        
        
//        _rigidbody.MovePosition(transform.position + transform.forward * force.z + transform.right * force.x);
//        _rigidbody.MovePosition(transform.position + new Vector3(_xAxis, 0, _zAxis).normalized * effectiveSpeed * Time.deltaTime);
//        transform.Translate(new Vector3(_xAxis, 0, _zAxis).normalized * effectiveSpeed * Time.deltaTime);
    }

    private void HandleTerrainOffset()
    {
        AdjustPositionToTerrain(transform);
    }

    private void AdjustPositionToTerrain(Transform transform)
    {
        var y = _terrain.SampleHeight(transform.position);
        var adjustedPosition = transform.position;
        adjustedPosition.y = y + _yOffset;
//        transform.position = adjustedPosition;
        _rigidbody.MovePosition(adjustedPosition);
    }

    private void HandleGrabAndDrop()
    {
        if (Input.GetButton("Grab") || Input.GetMouseButton(0))
        {
            _vaccumSound.volume = _vaccumSoundVolume;
            if (!_vaccumEffect.isPlaying)
            {
                _vaccumEffect.Play();
            }
        }
        else
        {
            _vaccumSound.volume = 0;
            if (_vaccumEffect.isPlaying)
            {
                _vaccumEffect.Stop();
            }
        }
        
        var animalInRange = FindAnimalInRange();
        if (animalInRange)
        {
            if (Input.GetButton("Grab") || Input.GetMouseButton(0))
            {
                
                if (_heldAnimals.Count < _maxHeldAnimals)
                {
                    _heldAnimals.Add(animalInRange);
                    animalInRange.OnGrab(_grabPoints[_heldAnimals.Count-1]);
//                    _isHoldingAnimal = true;
                }
            }
        }
        else
        {
            if ((Input.GetButtonDown("Drop") || Input.GetMouseButtonDown(1)) && _heldAnimals.Count > 0)
            {
                _heldAnimals.ForEach(a => a.OnDrop());
                _heldAnimals.Clear();
//                _heldAnimal.OnDrop();
//                _isHoldingAnimal = false;
            }
        }
    }

    private AnimalController FindAnimalInRange()
    {
        RaycastHit hit;
        if (Physics.SphereCast(transform.position, 0.7f /*radius*/, Vector3.down, out hit, _grabDistance, _animalLayerMask))
        {
//            Debug.Log($"spherecast Hit: {hit.collider.gameObject}", hit.collider.gameObject);
            var hitObject = hit.collider.gameObject;
            if (hitObject.CompareTag("Animal"))
            {
                return hitObject.GetComponentInParent<AnimalController>();
            }
        }

        return null;
    }
    
    private int RoundInput(float input)
    {
        if (input < -0.1f)
        {
            return -1;
        }

        if (input > 0.1f)
        {
            return 1;
        }

        return 0;
    }
    
    private void RotateModelTowardsMovementDirection(float zAxis, float xAxis)
    {
        var targetRotation = Quaternion.Euler(zAxis * _maxAngle, 0, xAxis * _maxAngle);
        _model.transform.rotation = Quaternion.Lerp(_model.transform.rotation, targetRotation, Time.deltaTime * _rotationSpeed);
    }

    private bool CanUseNitro()
    {
        return _fuelLevel >= _context.Settings.Player.MinFuelToNitro;
    }

    public bool TryRepair(int amount)
    {
        if (_playerHealth >= _context.Settings.Player.InitialHealth)
        {
            return false;
        }
        _playerHealth.Set((int) Mathf.Clamp(_playerHealth + amount, 0, _context.Settings.Player.InitialHealth));
        return true;
    }
    
    public bool TryRefuel(int amount)
    {
        if (_fuelLevel >= _context.Settings.Player.InitialFuel)
        {
            return false;
        }
        _fuelLevel.Set(Mathf.Clamp(_fuelLevel + amount, 0, _context.Settings.Player.InitialFuel));
        return true;
    }

    private void HandleRotation()
    {
        float mouseX = Input.GetAxis("Mouse X") * _mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * _mouseSensitivity * Time.deltaTime;

        
        var rotationX = transform.rotation.eulerAngles.x;
        var rotationY = transform.rotation.eulerAngles.y;
        
        rotationX += mouseY;
        rotationY += mouseX;
//        rotationX = Mathf.Clamp(rotationX, -90f, 90f);

//        transform.localRotation = Quaternion.Euler(-rotationX, rotationY, 0f);
//        transform.localRotation = Quaternion.Euler(0, rotationY, 0f);
        _rigidbody.MoveRotation(Quaternion.Euler(0, rotationY, 0f));
    }
    
    private void HandleFuel()
    {
        _fuelLevel.Set(Mathf.Clamp(_fuelLevel - _context.Settings.Player.FuelConsumptionPerSecond * Time.deltaTime, 0, _fuelLevel));
        if (_fuelLevel <= 0)
        {
            _context.State.OutOfFuel();
        }
    }
}
