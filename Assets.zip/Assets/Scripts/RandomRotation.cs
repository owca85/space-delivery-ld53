using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomRotation : MonoBehaviour
{
    [SerializeField] private Vector3 _axis;


    private void Start()
    {
        transform.Rotate(_axis, Random.Range(0, 360));     
    }

}
