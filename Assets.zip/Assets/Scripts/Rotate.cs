using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate : MonoBehaviour
{
    [SerializeField] private Vector3 _axis;

    [SerializeField] private float _speed;

    void Update()
    {
        transform.Rotate(_axis, Time.deltaTime*_speed);        
    }
}
