using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ServiceStation : MonoBehaviour
{
    [SerializeField] private int _amount = 1;
    [SerializeField] private float _interval = 1;
    [SerializeField] private ServiceStationType _type;
    
    
    private PlayerController _player;

    private bool _isPlayerInRange;
    
    void Start()
    {
        _player = FindAnyObjectByType<PlayerController>();
        StartCoroutine(Repair());
    }


    IEnumerator Repair()
    {
        while (true)
        {
            if (_isPlayerInRange)
            {
                switch (_type)
                {
                        case ServiceStationType.FuelStation:
                            _player.TryRefuel(_amount);
//                            Debug.Log($"Repfueling player");
                            break;
                        case ServiceStationType.RepairStation:
                            _player.TryRepair(_amount);
//                            Debug.Log($"Repairing player");
                            break;
                }
               
            }
            yield return new WaitForSeconds(_interval);
        }
    }
    
    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            _isPlayerInRange = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            _isPlayerInRange = false;
        }
        
    }
}
