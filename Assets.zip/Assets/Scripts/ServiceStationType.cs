﻿public enum ServiceStationType
{
    RepairStation,
    FuelStation
}