using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spike : MonoBehaviour
{
    [SerializeField] private GlobalContext _context;
    [SerializeField] private int _attack;
    private Animator _animator;

    private void Awake()
    {
        _animator = GetComponent<Animator>();
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            _context.State.PlayerHit(_attack);
        }
    }

    public void Attack()
    {
        _animator.SetTrigger("Attack");
    }
}
