using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpikePlant : MonoBehaviour
{
    [SerializeField] private Spike _spike;
    [SerializeField] private SphereCollider _rangeCollider;
    [SerializeField] private LayerMask _targetLayerMask;
    [SerializeField] private float _attackInterval = 3;
    [SerializeField] private float _attackPredictionTime = 0.5f;
    [SerializeField] private Animator _animator;

    private PlayerController _player;
    private bool _isPlayerInRange;

    private float _attackCooldown;

    private Coroutine _findTargetCoroutine;

    private Terrain _terrain;
    
    // Start is called before the first frame update
    void Start()
    {
        _player = FindObjectOfType<PlayerController>();
        _findTargetCoroutine = StartCoroutine(FindTarget());
        _terrain = FindObjectOfType<Terrain>();
        AdjustPositionToTerrain(transform);
    }

    private void AdjustPositionToTerrain(Transform transform)
    {
        var y = _terrain.SampleHeight(transform.position);
        var adjustedPosition = transform.position;
        adjustedPosition.y = y;
        transform.position = adjustedPosition;
    }

    // Update is called once per frame
    void Update()
    {
        if (_isPlayerInRange)
        {
            if (_attackCooldown <= 0)
            {
                Attack();
                _animator.SetTrigger("Attack");
                _attackCooldown = _attackInterval;
            }
        }

        _attackCooldown -= Time.deltaTime;
    }

    private void Attack()
    {
        _spike.transform.parent = null;
//        _spike.transform.position = _player.transform.position.Flatten();
        _spike.transform.position = _player.GetPredictedPosition(_attackPredictionTime).Flatten();
        AdjustPositionToTerrain(_spike.transform);
        _spike.Attack();
    }

    IEnumerator FindTarget()
    {
        while (true)
        {
//            _player = null;
//            foreach (var c in Physics.OverlapSphere(_rangeCollider.transform.position, _rangeCollider.radius, _targetLayerMask))
//            {
////                if (c.gameObject.CompareTag("Player"))
////                {
//                    _player = c.gameObject.GetComponentInParent<PlayerController>();
//                    break;
////                }
//            }
            _isPlayerInRange = Vector3.Distance(_player.transform.position, transform.position) <= _rangeCollider.radius;
            
            yield return new WaitForSeconds(.5f);
        }
    }
}