using UnityEngine;
using UnityEngine.SceneManagement;

public class StartGame : MonoBehaviour
{

    [SerializeField] private GameObject _howToPlay;

    private void Start()
    {
        if (_howToPlay)
        {
            _howToPlay.SetActive(false);
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            SceneManager.LoadScene(1);
        }
        
        
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        if (Input.GetKeyDown(KeyCode.H))
        {
            if (_howToPlay)
            {
                _howToPlay.SetActive(!_howToPlay.activeInHierarchy);
            }
        }
    }
}
