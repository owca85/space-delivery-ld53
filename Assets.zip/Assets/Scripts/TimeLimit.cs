using UnityEngine;

public class TimeLimit : MonoBehaviour
{
    [SerializeField] private GlobalContext _context;
    [SerializeField] private FloatReference _timeLeft;


    private void Start()
    {
        _timeLeft.Set(_context.Settings.Scoring.TimeLimit);
    }

    void Update()
    {
        _timeLeft.Set(Mathf.Clamp(_timeLeft - Time.deltaTime, 0, _timeLeft));
        if (_timeLeft <= 0)
        {
            _context.State.TimeOut();
        }
    }
}