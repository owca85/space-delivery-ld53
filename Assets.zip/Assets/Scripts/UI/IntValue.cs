using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class IntValue : MonoBehaviour
{
    [SerializeField] private FloatReference _value;
    [SerializeField] private bool _shortFormat = true;

    private TextMeshProUGUI _text;
    
    // Start is called before the first frame update
    void Start() {
        _text = GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update() {
        _text.text = _shortFormat ?  _value.Value.FormatWithSuffix() : Mathf.RoundToInt(_value.Value).ToString();
    }
}
