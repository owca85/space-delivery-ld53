using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerStatsController : MonoBehaviour
{
    [SerializeField] private GlobalContext _context;
    [SerializeField] private Image _healthBar;
    [SerializeField] private IntReference _healthValue;
    
    [SerializeField] private Image _fuelBar;
    [SerializeField] private FloatReference _fuelValue;
    

    // Update is called once per frame
    void Update()
    {
        var healthNormalized = _healthValue / _context.Settings.Player.InitialHealth;
        _healthBar.fillAmount = healthNormalized;

        var fuelNormalized = _fuelValue / _context.Settings.Player.InitialFuel;
        _fuelBar.fillAmount = fuelNormalized;

    }
}
