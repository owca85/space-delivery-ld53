﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class SliderValue : MonoBehaviour {

    [SerializeField] private FloatReference _value;
    [SerializeField] private string _playerPrefsKey;

    private Slider _slider;

    private void Awake() {
        _slider = GetComponent<Slider>();

        if (PlayerPrefs.HasKey(_playerPrefsKey)) {
            _value.Set(PlayerPrefs.GetFloat(_playerPrefsKey));
        }
        else {
            _value.Set(1);
        }
        
        _slider.value = _value;
        _slider.onValueChanged.AddListener(OnValueChanged);
    }

    private void OnValueChanged(float value) {
        _value.Set(value);
        PlayerPrefs.SetFloat(_playerPrefsKey, _value);
        PlayerPrefs.Save();
    }
}