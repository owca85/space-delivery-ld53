﻿using UnityEngine;
using UnityEngine.UI;

public class ToggleValue : MonoBehaviour {
    [SerializeField] private BoolReference _value;
    [SerializeField] private string _playerPrefsKey;

    private Toggle _toggle;

    private void Awake() {
        _toggle = GetComponent<Toggle>();

        if (PlayerPrefs.HasKey(_playerPrefsKey)) {
            _value.Set(PlayerPrefs.GetInt(_playerPrefsKey) == 1);
        }
        else {
            _value.Set(false);
        }

        _toggle.isOn = _value;
        _toggle.onValueChanged.AddListener(OnValueChanged);
    }

    private void OnValueChanged(bool value) {
        _value.Set(value);
        PlayerPrefs.SetInt(_playerPrefsKey, _value ? 1 : 0);
        PlayerPrefs.Save();
    }
}