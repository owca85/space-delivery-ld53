using System;
using TMPro;
using UnityEngine;

public class UIController : MonoBehaviour
{
    [SerializeField] private GlobalContext _context;
    [SerializeField] private TextMeshProUGUI _timeLeft;
    [SerializeField] private FloatReference _timeLeftValue;
    [SerializeField] private TextMeshProUGUI _animalsDelivered;
    [SerializeField] private IntReference _animalsDeliveredValue;

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        TimeSpan time = TimeSpan.FromSeconds(_timeLeftValue);
        string timeString = string.Format("{0:D2}:{1:D2}", time.Minutes, time.Seconds);
        _timeLeft.text = timeString;

        _animalsDelivered.text = _animalsDeliveredValue.Value.ToString();
    }
}