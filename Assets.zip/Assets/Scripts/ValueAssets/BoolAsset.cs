﻿using UnityEngine;

[CreateAssetMenu(menuName = "ValueAssets/BoolAsset")]
public class BoolAsset : ValueAsset<bool> {
}