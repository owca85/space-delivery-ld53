﻿using UnityEngine;

[CreateAssetMenu(menuName = "ValueAssets/FloatAsset")]
public class FloatAsset : ValueAsset<float> {
}