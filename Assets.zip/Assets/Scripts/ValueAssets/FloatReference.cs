﻿using System;

[Serializable]
public class FloatReference : ValueReference<float, FloatAsset> {
}