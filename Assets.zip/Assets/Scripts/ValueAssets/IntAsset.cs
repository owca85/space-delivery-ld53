﻿using UnityEngine;

[CreateAssetMenu(menuName = "ValueAssets/IntAsset")]
public class IntAsset : ValueAsset<int> {
}