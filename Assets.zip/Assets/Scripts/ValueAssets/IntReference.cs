﻿using System;

[Serializable]
public class IntReference : ValueReference<int, IntAsset> {
}