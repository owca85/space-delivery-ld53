﻿using UnityEngine;

[CreateAssetMenu(menuName = "ValueAssets/StringAsset")]
public class StringAsset : ValueAsset<string> {
}