﻿using System;

[Serializable]
public class StringReference : ValueReference<string, StringAsset> {
}