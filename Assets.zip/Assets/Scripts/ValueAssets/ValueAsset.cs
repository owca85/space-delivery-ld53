﻿using UnityEngine;

public abstract class ValueAsset<T> : ScriptableObject {
    public T Value;
}